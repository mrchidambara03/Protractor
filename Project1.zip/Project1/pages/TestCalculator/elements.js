var elements = function () {
    var firstNumber = element(by.model('first'));
    var secondNumber = element(by.model('second'));
    var goButton = element(by.id('gobutton'));
    var latestResult = element(by.binding('la'));
    this.launchBrowser = function () {
        browser.get('http://juliemr.github.io/protractor-demo/')
    }


    this.mathOperation = function (num1, num2, operation) {
        firstNumber.sendKeys(num1);
        operation.click()
        secondNumber.sendKeys(num2);
        goButton.click();
        if (operation.getText() == '+') {
            expect(latestResult.getText()).toEqual((num1 + num2).toString());
        }
        else if (operation.getText() == '-') {
            expect(latestResult.getText()).toEqual((num1 - num2).toString());
        }
        else if (operation.getText() == '/') {
            expect(latestResult.getText()).toEqual((num1 / num2).toString());
        }
        else if (operation.getText() == '%') {
            expect(latestResult.getText()).toEqual((num1 % num2).toString());
        }
        else if (operation.getText() == '*') {
            expect(latestResult.getText()).toEqual((num1 * num2).toString());
        }
    }


}

module.exports = new elements();