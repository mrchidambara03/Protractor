module.exports={
    Elements:{
        add: element(by.xpath('//select/option[1]')), 
        subtract: element(by.xpath('//select/option[5]')),
        multiply: element(by.xpath('//select/option[4]')),
        divide: element(by.xpath('//select/option[2]')),
        modulo: element(by.xpath('//select/option[3]'))
    }  
}