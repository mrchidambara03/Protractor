exports.config = {
  framework: 'jasmine',
  directConnect: true,
  seleniumAddress: 'http://localhost:4444/wd/hub',
  specs: ['tests/Strikingly/todo-spec.js'],
  capabilities: {
    browserName: 'firefox'
  }
  // suites: {
  //   homepage: 'tests/e2e/todo-spec.js',
    
  // }
  // multiCapabilities: [{
  //   browserName: 'firefox'
  // }, {
  //   browserName: 'chrome'
  // }]
  
}