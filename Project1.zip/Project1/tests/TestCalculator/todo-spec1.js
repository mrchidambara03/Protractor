// // spec.js
// describe('Protractor Demo App', function() {
//   it('should have a title', function() {
//     browser.get('http://juliemr.github.io/protractor-demo/');

//     expect(browser.getTitle()).toEqual('Super Calculator');
//   });
// });

describe ('protractorTest', function() {
      var firstNumber=element(by.model('first'));
      var secondNumber=element(by.model('second'));
      var goButton=element(by.id('gobutton'));
      var latestResult=element(by.binding('la'));
    

      beforeEach(function(){

          browser.get('http://juliemr.github.io/protractor-demo/');

      });

      it('add two numbers',function(){
            firstNumber.sendKeys(2);
            secondNumber.sendKeys(3);
            goButton.click();
            expect(latestResult.getText()).toEqual('5')
      });

      it('getting title',function(){
            expect(browser.getTitle()).toEqual('Super Calculator');
      });

      it('add 6 and 7',function(){
          firstNumber.sendKeys(6);
          secondNumber.sendKeys(7);
          goButton.click();
          expect(latestResult.getText()).toEqual('13')
      });

});