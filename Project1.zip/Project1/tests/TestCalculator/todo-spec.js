
var testCalculator=require("../../pages/TestCalculator/elements.js");
var testCalculator1=require("../../pages/TestCalculator/elements1.js");
describe('test angular JS calculator',function(){
        
        
        beforeEach(function(){
            testCalculator.launchBrowser()
        })
        it('add two numbers',function(){
                
                testCalculator.mathOperation(20,30,testCalculator1.Elements.add);
                testCalculator.mathOperation(20,30,testCalculator1.Elements.subtract);
                testCalculator.mathOperation(20,30,testCalculator1.Elements.divide);
                testCalculator.mathOperation(20,30,testCalculator1.Elements.multiply);
                testCalculator.mathOperation(20,30,testCalculator1.Elements.modulo);
                
                browser.sleep(3000)
        });   
        
});