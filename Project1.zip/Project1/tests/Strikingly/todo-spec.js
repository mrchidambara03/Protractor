// Protractor expects Angular to be present on a page, so it will throw an error if the page it is attempting to load does 
// not contain the Angular library. (If you need to interact with a non-Angular page, you may access the wrapped 
// webdriver instance directly with browser.driver).
// @isAngularSite
describe('test', function () {
    beforeEach(function() {
      return browser.ignoreSynchronization = true;
    });
    it('launchBrowser',function(){
        browser.driver.get('http://toolsqa.com/automation-practice-form/')
    },500)
    it('form filling',function(){
        expect(element(by.xpath('.//*[@id="content"]/h1')).getText().toEqual='Automation Practice Form')
    },500)
    // @isAngularSite
    // it('assert title', function () {
    //     expect(element(by.xpath('html/body/div[2]/div[1]/div[3]/div/div[1]/img')).getText().toEqual = 'strikingly')
    // })
})