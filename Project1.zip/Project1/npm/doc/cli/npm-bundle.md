npm-bundle(1) -- REMOVED
========================

## DESCRIPTION

The `npm bundle` command has been removed in 1.0, for the simple reason
that it is no longer necessary, as the default behavior is now to
install packages into the local space.

Just use `npm install` now to do what `npm bundle` used to do.

## SEE ALSO

* npm-install(1)
