npm-bin(1) -- Display npm bin folder
====================================

## SYNOPSIS

    npm bin [-g|--global]

## DESCRIPTION

Print the folder where npm will install executables.

## SEE ALSO

* npm-prefix(1)
* npm-root(1)
* npm-folders(5)
* npm-config(1)
* npm-config(7)
* npmrc(5)
